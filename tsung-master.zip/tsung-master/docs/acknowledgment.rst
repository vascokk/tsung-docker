===============
Acknowledgments
===============

The first version of this document was based on a talk given by Mickael
Rémond [#1]_ during an Object
Web benchmarking workshop in April 2004 (more info at
http://jmob.objectweb.org/).

.. [#1] mickael.remond@erlang-fr.org
